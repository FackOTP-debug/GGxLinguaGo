package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.engine.TranslationEngine
import com.example.data.model.SupportedLanguages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("OmniTranslate", appName)
    }

    @Test
    fun `test language detection and models`() {
        val detected = TranslationEngine.detectLanguage("hola amigo")
        assertEquals("es", detected)

        val esLang = SupportedLanguages.getByCode("es")
        assertEquals("Spanish", esLang.name)
        assertNotNull(esLang.flagEmoji)
    }
}
