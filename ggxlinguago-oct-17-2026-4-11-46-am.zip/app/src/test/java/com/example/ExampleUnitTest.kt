package com.example

import com.example.data.engine.OfflineDictionaryEngine
import com.example.data.engine.TranslationEngine
import com.example.data.model.SupportedLanguages
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testPredefined100PlusLanguagesList() {
        val languages = SupportedLanguages.ALL_LANGUAGES
        assertTrue("Expected 100+ languages, found: ${languages.size}", languages.size >= 100)

        // Verify languages from multiple continents
        val testCodes = listOf(
            "es" to "Spanish",
            "fr" to "French",
            "de" to "German",
            "ja" to "Japanese",
            "zh" to "Chinese (Simplified)",
            "ar" to "Arabic",
            "hi" to "Hindi",
            "sw" to "Swahili",
            "am" to "Amharic",
            "ta" to "Tamil",
            "is" to "Icelandic",
            "eo" to "Esperanto",
            "zu" to "Zulu",
            "vi" to "Vietnamese",
            "uk" to "Ukrainian"
        )

        testCodes.forEach { (code, expectedName) ->
            val lang = SupportedLanguages.getByCode(code)
            assertEquals("Language code $code", expectedName, lang.name)
            assertNotNull("Flag for $code", lang.flagEmoji)
        }

        val auto = SupportedLanguages.getByCode("auto")
        assertTrue(auto.isAutoDetect)
        assertFalse(auto.isOfflineSupported)
    }

    @Test
    fun testMultilingualTranslations() = runTest {
        // Test translation into Spanish
        val resEs = TranslationEngine.translate("hello", "en", "es", false)
        assertEquals("hola", resEs.translatedText.lowercase())

        // Test translation into Japanese
        val resJa = TranslationEngine.translate("hello", "en", "ja", false)
        assertEquals("こんにちは", resJa.translatedText)

        // Test translation into Swahili
        val resSw = TranslationEngine.translate("thank you", "en", "sw", false)
        assertEquals("asante", resSw.translatedText.lowercase())

        // Test translation into Arabic
        val resAr = TranslationEngine.translate("hello", "en", "ar", false)
        assertEquals("مرحبا", resAr.translatedText)
    }

    @Test
    fun testLanguageSearchFilter() {
        val languages = SupportedLanguages.ALL_LANGUAGES
        val searchSpanish = languages.filter {
            it.name.contains("Span", ignoreCase = true) || it.code == "es"
        }
        assertEquals(1, searchSpanish.size)
        assertEquals("es", searchSpanish.first().code)

        val searchArabic = languages.filter {
            it.name.contains("Arab", ignoreCase = true)
        }
        assertEquals(1, searchArabic.size)
    }
}
