package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FileDownloadDone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.OfflinePackEntity
import com.example.data.model.Language
import com.example.data.model.SupportedLanguages

/**
 * Bottom Sheet Language Selector Component.
 * Allows users to search and select source or target languages from the pre-defined list,
 * displaying offline status, native scripts, and quick recent chips.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageSelectorBottomSheet(
    isSelectingSource: Boolean,
    currentSelected: Language,
    offlinePacks: List<OfflinePackEntity> = emptyList(),
    onLanguageSelected: (Language) -> Unit,
    onDismissRequest: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searchQuery by remember { mutableStateOf("") }

    val downloadedCodes = remember(offlinePacks) {
        offlinePacks.filter { it.isDownloaded }.map { it.langCode }.toSet()
    }

    val baseList = remember(isSelectingSource) {
        if (isSelectingSource) {
            listOf(SupportedLanguages.AUTO_DETECT) + SupportedLanguages.ALL_LANGUAGES
        } else {
            SupportedLanguages.ALL_LANGUAGES
        }
    }

    val popularLanguages = remember(isSelectingSource) {
        val popularCodes = listOf("en", "es", "fr", "de", "ja", "zh", "hi", "ar", "pt")
        baseList.filter { popularCodes.contains(it.code) || it.isAutoDetect }
    }

    val filteredLanguages by remember(baseList, searchQuery) {
        derivedStateOf {
            if (searchQuery.isBlank()) {
                baseList
            } else {
                val q = searchQuery.trim().lowercase()
                baseList.filter {
                    it.name.lowercase().contains(q) ||
                        it.nativeName.lowercase().contains(q) ||
                        it.code.lowercase().contains(q)
                }
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("language_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(horizontal = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSelectingSource) "Select Source Language" else "Select Target Language",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.testTag("close_language_modal")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Language Selector")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("language_search_input"),
                placeholder = { Text("Search 100+ languages...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search languages")
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search query")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Popular / Recent quick chips
            if (searchQuery.isBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Popular Languages",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(popularLanguages, key = { "chip_${it.code}" }) { lang ->
                        val isSelected = lang.code == currentSelected.code
                        InputChip(
                            selected = isSelected,
                            onClick = {
                                onLanguageSelected(lang)
                                onDismissRequest()
                            },
                            label = {
                                Text(
                                    text = if (lang.isAutoDetect) "Detect" else "${lang.flagEmoji} ${lang.name}",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag("quick_chip_${lang.code}")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Language List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(filteredLanguages, key = { it.code }) { lang ->
                    val isSelected = lang.code == currentSelected.code
                    val isDownloaded = downloadedCodes.contains(lang.code)

                    LanguageListItem(
                        language = lang,
                        isSelected = isSelected,
                        isDownloaded = isDownloaded,
                        onClick = {
                            onLanguageSelected(lang)
                            onDismissRequest()
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * Drop-Down Menu Language Selector Component.
 * Provides a compact, anchorable drop-down menu to pick a language directly in place.
 */
@Composable
fun LanguageDropdownMenu(
    expanded: Boolean,
    isSelectingSource: Boolean,
    currentSelected: Language,
    offlinePacks: List<OfflinePackEntity> = emptyList(),
    onDismissRequest: () -> Unit,
    onLanguageSelected: (Language) -> Unit,
    modifier: Modifier = Modifier
) {
    val downloadedCodes = remember(offlinePacks) {
        offlinePacks.filter { it.isDownloaded }.map { it.langCode }.toSet()
    }

    val availableLanguages = remember(isSelectingSource) {
        if (isSelectingSource) {
            listOf(SupportedLanguages.AUTO_DETECT) + SupportedLanguages.ALL_LANGUAGES
        } else {
            SupportedLanguages.ALL_LANGUAGES
        }
    }

    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = modifier
            .widthIn(min = 220.dp, max = 280.dp)
            .heightIn(max = 380.dp)
            .testTag("language_dropdown_menu")
    ) {
        Text(
            text = if (isSelectingSource) "Select Source" else "Select Target",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        HorizontalDivider()

        availableLanguages.forEach { lang ->
            val isSelected = lang.code == currentSelected.code
            val isDownloaded = downloadedCodes.contains(lang.code)

            DropdownMenuItem(
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = lang.flagEmoji,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = lang.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            if (lang.nativeName != lang.name && !lang.isAutoDetect) {
                                Text(
                                    text = lang.nativeName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (isDownloaded && !lang.isAutoDetect) {
                            Icon(
                                Icons.Default.FileDownloadDone,
                                contentDescription = "Offline pack ready",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(end = 4.dp)
                            )
                        }
                        if (isSelected) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                onClick = {
                    onLanguageSelected(lang)
                    onDismissRequest()
                },
                modifier = Modifier.testTag("dropdown_item_${lang.code}")
            )
        }
    }
}

/**
 * Language Selection Bar with Swap and Modal / Dropdown trigger support.
 */
@Composable
fun LanguageSelectionBar(
    sourceLang: Language,
    targetLang: Language,
    offlinePacks: List<OfflinePackEntity>,
    onSourceClick: () -> Unit,
    onTargetClick: () -> Unit,
    onSwapClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Source Language Selector
            TextButton(
                onClick = onSourceClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("source_lang_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (sourceLang.isAutoDetect) "🌐 Detect language" else "${sourceLang.flagEmoji} ${sourceLang.name}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = "Open Source Language Menu",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Swap Languages Button
            IconButton(
                onClick = onSwapClick,
                modifier = Modifier.testTag("swap_languages_button")
            ) {
                Icon(
                    Icons.Default.SwapHoriz,
                    contentDescription = "Swap Languages",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            // Target Language Selector
            TextButton(
                onClick = onTargetClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("target_lang_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${targetLang.flagEmoji} ${targetLang.name}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = "Open Target Language Menu",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageListItem(
    language: Language,
    isSelected: Boolean,
    isDownloaded: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp)
            .testTag("lang_item_${language.code}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = language.flagEmoji,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(end = 16.dp)
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = language.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            if (language.nativeName != language.name && !language.isAutoDetect) {
                Text(
                    text = language.nativeName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (isDownloaded && !language.isAutoDetect) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.FileDownloadDone,
                        contentDescription = "Offline pack downloaded",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Offline Ready",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        if (isSelected) {
            Icon(
                Icons.Default.Check,
                contentDescription = "Selected",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

// Backward-compatibility alias
@Composable
fun LanguageSelectorModal(
    isSelectingSource: Boolean,
    currentSelected: Language,
    offlinePacks: List<OfflinePackEntity> = emptyList(),
    onLanguageSelected: (Language) -> Unit,
    onDismissRequest: () -> Unit
) {
    LanguageSelectorBottomSheet(
        isSelectingSource = isSelectingSource,
        currentSelected = currentSelected,
        offlinePacks = offlinePacks,
        onLanguageSelected = onLanguageSelected,
        onDismissRequest = onDismissRequest
    )
}
