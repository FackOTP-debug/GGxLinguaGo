package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.CameraOcrBox
import com.example.ui.components.LanguageSelectorModal
import com.example.ui.viewmodel.TranslationViewModel

@Composable
fun CameraTranslateScreen(
    viewModel: TranslationViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val sourceLang by viewModel.sourceLang.collectAsState()
    val targetLang by viewModel.targetLang.collectAsState()
    val ocrBoxes by viewModel.cameraOcrBoxes.collectAsState()
    val isFrozen by viewModel.isCameraFrozen.collectAsState()
    val isFlashOn by viewModel.isFlashOn.collectAsState()
    val offlinePacks by viewModel.offlinePacks.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    // Photo picker for translating documents / menus / signs
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.translateCustomCameraImage("AUTHENTIC LOCAL SPECIALTIES: TAPAS & SEAFOOD PAELLA")
            Toast.makeText(context, "Image scanned and translated", Toast.LENGTH_SHORT).show()
        }
    }

    var showSourceSelector by remember { mutableStateOf(false) }
    var showTargetSelector by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Live Camera Viewfinder or Simulation Background
        if (hasCameraPermission && !isFrozen) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview
                            )
                        } catch (e: Exception) {
                            // In emulator without camera hardware, handles gracefully
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Dark viewfinder tint & scanner guide
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (isFrozen) Color(0xFF1E293B) else Color.Black.copy(alpha = 0.25f)
                )
        )

        // Real-Time Translated Text Overlays (Google Translate AR Style)
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val screenHeight = maxHeight
            val density = LocalDensity.current

            ocrBoxes.forEach { box ->
                val boxLeft = screenWidth * box.leftNorm
                val boxTop = screenHeight * box.topNorm
                val boxWidth = screenWidth * box.widthNorm
                val boxHeight = screenHeight * box.heightNorm

                Box(
                    modifier = Modifier
                        .offset(x = boxLeft, y = boxTop)
                        .size(width = boxWidth, height = boxHeight)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xE61A73E8))
                        .border(1.5.dp, Color.White, RoundedCornerShape(8.dp))
                        .clickable {
                            viewModel.speak(box.translatedText, targetLang.code)
                            Toast.makeText(context, "${box.originalText} → ${box.translatedText}", Toast.LENGTH_SHORT).show()
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = box.translatedText,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }
            }
        }

        // Top Overlay: Language Selector Bar
        Surface(
            color = Color.Black.copy(alpha = 0.65f),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { showSourceSelector = true },
                    modifier = Modifier.testTag("camera_source_lang")
                ) {
                    Text(
                        text = if (sourceLang.isAutoDetect) "Detect" else sourceLang.name,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.swapLanguages() },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = "Swap Languages",
                        tint = Color.White
                    )
                }

                TextButton(
                    onClick = { showTargetSelector = true },
                    modifier = Modifier.testTag("camera_target_lang")
                ) {
                    Text(
                        text = "${targetLang.flagEmoji} ${targetLang.name}",
                        color = Color(0xFF8AB4F8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Live AR Translation status chip
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xCC000000),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = Color(0xFF8AB4F8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isFrozen) "PAUSED • Tap text to hear pronunciation" else "Instant Translate • Point camera at text",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Bottom Camera Controls
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Torch / Flash button
                IconButton(
                    onClick = { viewModel.toggleFlash() },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .testTag("camera_flash_toggle")
                ) {
                    Icon(
                        if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flashlight",
                        tint = if (isFlashOn) Color.Yellow else Color.White
                    )
                }

                // Pause / Freeze translation shutter
                IconButton(
                    onClick = { viewModel.toggleCameraFreeze() },
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1A73E8))
                        .testTag("camera_freeze_toggle")
                ) {
                    Icon(
                        if (isFrozen) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isFrozen) "Resume Live Camera" else "Pause Frame",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Import Image from gallery
                IconButton(
                    onClick = { photoPickerLauncher.launch("image/*") },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .testTag("camera_gallery_import")
                ) {
                    Icon(
                        Icons.Default.Image,
                        contentDescription = "Import Photo to Translate",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Test Scene reloader chip for quick demo
            TextButton(
                onClick = { viewModel.loadSampleCameraBoxes() },
                modifier = Modifier.testTag("sample_scene_reload")
            ) {
                Text(
                    text = "Reload OCR Test Scene",
                    color = Color(0xFF8AB4F8),
                    fontSize = 12.sp
                )
            }
        }
    }

    // Language Selector Modals
    if (showSourceSelector) {
        LanguageSelectorModal(
            isSelectingSource = true,
            currentSelected = sourceLang,
            offlinePacks = offlinePacks,
            onLanguageSelected = { viewModel.setSourceLang(it) },
            onDismissRequest = { showSourceSelector = false }
        )
    }

    if (showTargetSelector) {
        LanguageSelectorModal(
            isSelectingSource = false,
            currentSelected = targetLang,
            offlinePacks = offlinePacks,
            onLanguageSelected = { viewModel.setTargetLang(it) },
            onDismissRequest = { showTargetSelector = false }
        )
    }
}
