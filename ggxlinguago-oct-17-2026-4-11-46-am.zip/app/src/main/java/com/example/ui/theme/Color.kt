package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Google Translate Palette
val GoogleBlue = Color(0xFF1A73E8)
val GoogleBlueDark = Color(0xFF8AB4F8)
val GoogleBlueContainerLight = Color(0xFFE8F0FE)
val GoogleBlueContainerDark = Color(0xFF174EA6)

val TranslateTeal = Color(0xFF00897B)
val TranslateAmber = Color(0xFFF9AB00)
val TranslateRed = Color(0xFFEA4335)
val TranslateGreen = Color(0xFF34A853)

// Light Theme Neutrals
val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F3F4)
val LightOnSurface = Color(0xFF202124)
val LightOnSurfaceVariant = Color(0xFF5F6368)
val LightOutline = Color(0xFFDADCE0)

// Night / Dark Theme Neutrals
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2D2F31)
val DarkOnSurface = Color(0xFFE8EAED)
val DarkOnSurfaceVariant = Color(0xFF9AA0A6)
val DarkOutline = Color(0xFF3C4043)
