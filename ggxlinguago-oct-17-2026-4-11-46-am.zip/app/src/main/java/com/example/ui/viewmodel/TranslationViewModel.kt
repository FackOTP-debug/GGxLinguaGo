package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.engine.TranslationEngine
import com.example.data.local.AnalyticsEventEntity
import com.example.data.local.OfflinePackEntity
import com.example.data.local.SavedPhraseEntity
import com.example.data.local.TranslationHistoryEntity
import com.example.data.model.CameraOcrBox
import com.example.data.model.Language
import com.example.data.model.SupportedLanguages
import com.example.data.model.ThemeMode
import com.example.data.model.TranslationResult
import com.example.data.repository.TranslationRepository
import com.example.data.speech.SpeechRecognizerManager
import com.example.data.speech.SpeechState
import com.example.data.tts.TtsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    TRANSLATE,
    CAMERA,
    CONVERSATION,
    SAVED,
    OFFLINE_PACKS,
    PHRASEBOOK,
    ANALYTICS,
    SETTINGS
}

data class ConversationMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val senderName: String,
    val originalText: String,
    val translatedText: String,
    val langCode: String,
    val isUserA: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class TranslationViewModel(
    private val repository: TranslationRepository,
    private val ttsManager: TtsManager,
    private val speechManager: SpeechRecognizerManager
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(AppTab.TRANSLATE)
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()

    private val _sourceLang = MutableStateFlow(SupportedLanguages.AUTO_DETECT)
    val sourceLang: StateFlow<Language> = _sourceLang.asStateFlow()

    private val _targetLang = MutableStateFlow(SupportedLanguages.getByCode("es"))
    val targetLang: StateFlow<Language> = _targetLang.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _translationResult = MutableStateFlow<TranslationResult?>(null)
    val translationResult: StateFlow<TranslationResult?> = _translationResult.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    // History and Packs from DB
    val history: StateFlow<List<TranslationHistoryEntity>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val starredHistory: StateFlow<List<TranslationHistoryEntity>> = repository.starredHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlinePacks: StateFlow<List<OfflinePackEntity>> = repository.allPacks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val analyticsEvents: StateFlow<List<AnalyticsEventEntity>> = repository.analyticsEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isOfflineOnlyMode = repository.isOfflineOnlyMode
    val isLowEndDeviceMode = repository.isLowEndDeviceMode
    val themeMode = repository.themeMode
    val isSpeaking = ttsManager.isSpeaking
    val currentlySpeakingText: StateFlow<String?> = ttsManager.currentlySpeakingText
    val speechRate: StateFlow<Float> = ttsManager.speechRate
    val speechState: StateFlow<SpeechState> = speechManager.speechState

    fun startSpeechToTextInput() {
        val lang = if (_sourceLang.value.isAutoDetect) "en" else _sourceLang.value.code
        speechManager.startListening(lang) { recognizedText ->
            onInputTextChanged(recognizedText)
        }
    }

    fun stopVoiceInput() {
        speechManager.stopListening()
    }

    fun cancelVoiceInput() {
        speechManager.cancel()
    }

    // Camera Real-time Translation State
    private val _cameraOcrBoxes = MutableStateFlow<List<CameraOcrBox>>(emptyList())
    val cameraOcrBoxes: StateFlow<List<CameraOcrBox>> = _cameraOcrBoxes.asStateFlow()

    private val _isCameraFrozen = MutableStateFlow(false)
    val isCameraFrozen: StateFlow<Boolean> = _isCameraFrozen.asStateFlow()

    private val _isFlashOn = MutableStateFlow(false)
    val isFlashOn: StateFlow<Boolean> = _isFlashOn.asStateFlow()

    // Conversation Mode State
    private val _conversationMessages = MutableStateFlow<List<ConversationMessage>>(emptyList())
    val conversationMessages: StateFlow<List<ConversationMessage>> = _conversationMessages.asStateFlow()

    private val _isListeningPersonA = MutableStateFlow(false)
    val isListeningPersonA: StateFlow<Boolean> = _isListeningPersonA.asStateFlow()

    private val _isListeningPersonB = MutableStateFlow(false)
    val isListeningPersonB: StateFlow<Boolean> = _isListeningPersonB.asStateFlow()

    // Phrasebook state
    private val _phrases = MutableStateFlow<List<SavedPhraseEntity>>(emptyList())
    val phrases: StateFlow<List<SavedPhraseEntity>> = _phrases.asStateFlow()

    private val _selectedPhraseCategory = MutableStateFlow("All")
    val selectedPhraseCategory: StateFlow<String> = _selectedPhraseCategory.asStateFlow()

    private var debounceJob: Job? = null

    init {
        loadPhrasesForCurrentTarget()
        loadSampleCameraBoxes()
        initDefaultConversation()
    }

    fun selectTab(tab: AppTab) {
        _selectedTab.value = tab
    }

    fun setSourceLang(language: Language) {
        _sourceLang.value = language
        triggerTranslation(_inputText.value)
    }

    fun setTargetLang(language: Language) {
        if (language.isAutoDetect) return // Target cannot be auto-detect
        _targetLang.value = language
        loadPhrasesForCurrentTarget()
        loadSampleCameraBoxes()
        triggerTranslation(_inputText.value)
    }

    fun swapLanguages() {
        val currentSource = _sourceLang.value
        val currentTarget = _targetLang.value

        if (currentSource.isAutoDetect) {
            // If source was auto-detect, set it to the detected lang or target
            val detectedCode = _translationResult.value?.sourceLangCode ?: "en"
            _sourceLang.value = currentTarget
            _targetLang.value = SupportedLanguages.getByCode(detectedCode)
        } else {
            _sourceLang.value = currentTarget
            _targetLang.value = currentSource
        }

        // Also swap text if translated text exists
        val currentTranslation = _translationResult.value
        if (currentTranslation != null && currentTranslation.translatedText.isNotBlank()) {
            _inputText.value = currentTranslation.translatedText
            triggerTranslation(currentTranslation.translatedText)
        } else {
            triggerTranslation(_inputText.value)
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
        debounceJob?.cancel()
        if (text.isBlank()) {
            _translationResult.value = null
            _isTranslating.value = false
            return
        }

        debounceJob = viewModelScope.launch {
            _isTranslating.value = true
            // Debounce 250ms for smooth low-latency typing
            delay(250)
            executeTranslation(text)
        }
    }

    fun clearInput() {
        _inputText.value = ""
        _translationResult.value = null
        _isTranslating.value = false
    }

    private fun triggerTranslation(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isTranslating.value = true
            executeTranslation(text)
        }
    }

    private suspend fun executeTranslation(text: String) {
        try {
            val result = repository.translate(
                text = text,
                sourceLangCode = _sourceLang.value.code,
                targetLangCode = _targetLang.value.code,
                mode = "TEXT"
            )
            _translationResult.value = result
        } catch (e: Exception) {
            // Graceful fallback
        } finally {
            _isTranslating.value = false
        }
    }

    fun speak(text: String, langCode: String, isSlow: Boolean = false) {
        ttsManager.speak(text, langCode, isSlow)
    }

    fun toggleSpeak(text: String, langCode: String, isSlow: Boolean = false) {
        ttsManager.toggleSpeak(text, langCode, isSlow)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    fun setSpeechRate(rate: Float) {
        ttsManager.setSpeechRate(rate)
    }

    fun toggleStarred(historyItem: TranslationHistoryEntity) {
        viewModelScope.launch {
            repository.toggleHistoryStarred(historyItem.id, historyItem.isStarred)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteHistory(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    // Camera Real-Time OCR actions
    fun loadSampleCameraBoxes() {
        _cameraOcrBoxes.value = TranslationEngine.getSampleCameraOcrBoxes(_targetLang.value.code)
    }

    fun toggleCameraFreeze() {
        _isCameraFrozen.value = !_isCameraFrozen.value
    }

    fun toggleFlash() {
        _isFlashOn.value = !_isFlashOn.value
    }

    fun translateCustomCameraImage(recognizedText: String) {
        viewModelScope.launch {
            val res = repository.translate(
                text = recognizedText,
                sourceLangCode = _sourceLang.value.code,
                targetLangCode = _targetLang.value.code,
                mode = "CAMERA"
            )
            _cameraOcrBoxes.value = listOf(
                CameraOcrBox(
                    id = "custom_image_ocr",
                    originalText = recognizedText,
                    translatedText = res.translatedText,
                    leftNorm = 0.1f,
                    topNorm = 0.35f,
                    widthNorm = 0.8f,
                    heightNorm = 0.2f
                )
            )
        }
    }

    // Conversation Mode actions
    private fun initDefaultConversation() {
        val targetName = _targetLang.value.name
        _conversationMessages.value = listOf(
            ConversationMessage(
                senderName = "You (English)",
                originalText = "Hello! Do you have a table for two?",
                translatedText = when (_targetLang.value.code) {
                    "es" -> "¡Hola! ¿Tiene una mesa para dos?"
                    "fr" -> "Bonjour ! Avez-vous une table pour deux ?"
                    "de" -> "Hallo! Haben Sie einen Tisch für zwei Personen?"
                    "ja" -> "こんにちは！2名用のテーブルはありますか？"
                    else -> "Hello! Do you have a table for two?"
                },
                langCode = "en",
                isUserA = true
            ),
            ConversationMessage(
                senderName = "Local ($targetName)",
                originalText = when (_targetLang.value.code) {
                    "es" -> "¡Sí, por supuesto! Síganme por favor."
                    "fr" -> "Oui bien sûr ! Suivez-moi s'il vous plaît."
                    "de" -> "Ja, natürlich! Folgen Sie mir bitte."
                    "ja" -> "はい、もちろん！ご案内します。"
                    else -> "Yes, of course! Follow me please."
                },
                translatedText = "Yes, of course! Follow me please.",
                langCode = _targetLang.value.code,
                isUserA = false
            )
        )
    }

    fun sendConversationUtterance(text: String, isPersonA: Boolean) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val src = if (isPersonA) _sourceLang.value.code.let { if (it == "auto") "en" else it } else _targetLang.value.code
            val dst = if (isPersonA) _targetLang.value.code else "en"

            val result = repository.translate(
                text = text,
                sourceLangCode = src,
                targetLangCode = dst,
                mode = "CONVERSATION"
            )

            val newMessage = ConversationMessage(
                senderName = if (isPersonA) "You (${SupportedLanguages.getByCode(src).name})" else "Local (${SupportedLanguages.getByCode(src).name})",
                originalText = text,
                translatedText = result.translatedText,
                langCode = src,
                isUserA = isPersonA
            )

            _conversationMessages.value = _conversationMessages.value + newMessage

            // Auto-speak translation for natural conversation
            ttsManager.speak(result.translatedText, dst)
        }
    }

    fun startListeningPersonA() {
        _isListeningPersonA.value = true
        _isListeningPersonB.value = false
        val lang = if (_sourceLang.value.isAutoDetect) "en" else _sourceLang.value.code
        speechManager.startListening(lang) { text ->
            _isListeningPersonA.value = false
            sendConversationUtterance(text, isPersonA = true)
        }
    }

    fun stopListeningPersonA(speechResult: String? = null) {
        _isListeningPersonA.value = false
        speechManager.stopListening()
        if (!speechResult.isNullOrBlank()) {
            sendConversationUtterance(speechResult, isPersonA = true)
        }
    }

    fun startListeningPersonB() {
        _isListeningPersonB.value = true
        _isListeningPersonA.value = false
        val lang = _targetLang.value.code
        speechManager.startListening(lang) { text ->
            _isListeningPersonB.value = false
            sendConversationUtterance(text, isPersonA = false)
        }
    }

    fun stopListeningPersonB(speechResult: String? = null) {
        _isListeningPersonB.value = false
        speechManager.stopListening()
        if (!speechResult.isNullOrBlank()) {
            sendConversationUtterance(speechResult, isPersonA = false)
        }
    }

    // Offline Packs
    fun downloadOfflinePack(langCode: String) {
        repository.downloadPack(langCode)
    }

    fun removeOfflinePack(langCode: String) {
        viewModelScope.launch {
            repository.removePack(langCode)
        }
    }

    fun toggleOfflineOnlyMode(enabled: Boolean) {
        repository.setOfflineOnlyMode(enabled)
    }

    fun toggleLowEndDeviceMode(enabled: Boolean) {
        repository.setLowEndDeviceMode(enabled)
    }

    fun setThemeMode(mode: ThemeMode) {
        repository.setThemeMode(mode)
    }

    // Phrasebook
    private fun loadPhrasesForCurrentTarget() {
        viewModelScope.launch {
            repository.getPhrasesForLang(_targetLang.value.code).collect { list ->
                _phrases.value = list
            }
        }
    }

    fun setPhraseCategory(cat: String) {
        _selectedPhraseCategory.value = cat
    }

    fun togglePhraseFavorite(phrase: SavedPhraseEntity) {
        viewModelScope.launch {
            repository.togglePhraseFavorite(phrase.id, phrase.isFavorite)
        }
    }

    fun addCustomPhrase(category: String, english: String, translated: String) {
        viewModelScope.launch {
            repository.addCustomPhrase(category, english, translated, _targetLang.value.code)
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechManager.destroy()
    }
}
