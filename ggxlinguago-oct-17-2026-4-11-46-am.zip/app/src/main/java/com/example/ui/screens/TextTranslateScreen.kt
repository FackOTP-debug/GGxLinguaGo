package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.core.content.ContextCompat
import com.example.data.speech.SpeechState
import com.example.ui.components.VoiceRecognitionOverlay
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.TranslationHistoryEntity
import com.example.data.model.SupportedLanguages
import com.example.ui.components.LanguageSelectorModal
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.TranslationViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextTranslateScreen(
    viewModel: TranslationViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val sourceLang by viewModel.sourceLang.collectAsState()
    val targetLang by viewModel.targetLang.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val translationResult by viewModel.translationResult.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val currentlySpeakingText by viewModel.currentlySpeakingText.collectAsState()
    val offlinePacks by viewModel.offlinePacks.collectAsState()
    val isOfflineOnly by viewModel.isOfflineOnlyMode.collectAsState()
    val historyList by viewModel.history.collectAsState()

    var showSourceSelector by remember { mutableStateOf(false) }
    var showTargetSelector by remember { mutableStateOf(false) }
    var showSourceDropdown by remember { mutableStateOf(false) }
    var showTargetDropdown by remember { mutableStateOf(false) }
    var showFullscreenDialog by remember { mutableStateOf(false) }

    val speechState by viewModel.speechState.collectAsState()
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            viewModel.startSpeechToTextInput()
        } else {
            Toast.makeText(context, "Microphone permission is required for voice translation", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Language Selector Bar with both Drop-down Menu and Bottom Sheet capabilities
        Surface(
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language Selector (with both Dropdown and Bottom Sheet support)
                Box(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showSourceSelector = true }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("source_lang_button")
                    ) {
                        Text(
                            text = if (sourceLang.isAutoDetect) "Detect" else "${sourceLang.flagEmoji} ${sourceLang.name}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { showSourceDropdown = true },
                            modifier = Modifier.size(28.dp).testTag("source_dropdown_trigger")
                        ) {
                            Icon(
                                Icons.Default.ArrowDropDown,
                                contentDescription = "Source Language Drop-down Menu",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    com.example.ui.components.LanguageDropdownMenu(
                        expanded = showSourceDropdown,
                        isSelectingSource = true,
                        currentSelected = sourceLang,
                        offlinePacks = offlinePacks,
                        onDismissRequest = { showSourceDropdown = false },
                        onLanguageSelected = { viewModel.setSourceLang(it) }
                    )
                }

                // Swap Button
                IconButton(
                    onClick = { viewModel.swapLanguages() },
                    modifier = Modifier.testTag("swap_languages_button")
                ) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = "Swap Languages",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                // Target Language Selector (with both Dropdown and Bottom Sheet support)
                Box(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showTargetSelector = true }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("target_lang_button")
                    ) {
                        Text(
                            text = "${targetLang.flagEmoji} ${targetLang.name}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { showTargetDropdown = true },
                            modifier = Modifier.size(28.dp).testTag("target_dropdown_trigger")
                        ) {
                            Icon(
                                Icons.Default.ArrowDropDown,
                                contentDescription = "Target Language Drop-down Menu",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    com.example.ui.components.LanguageDropdownMenu(
                        expanded = showTargetDropdown,
                        isSelectingSource = false,
                        currentSelected = targetLang,
                        offlinePacks = offlinePacks,
                        onDismissRequest = { showTargetDropdown = false },
                        onLanguageSelected = { viewModel.setTargetLang(it) }
                    )
                }
            }
        }

        // Offline mode indicator badge
        if (isOfflineOnly) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "⚡ Offline Mode active • Zero cellular data used",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Source Input Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (sourceLang.isAutoDetect) "Detecting..." else sourceLang.name,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            if (inputText.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.clearInput() },
                                    modifier = Modifier.size(32.dp).testTag("clear_input_button")
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear text", modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { viewModel.onInputTextChanged(it) },
                            placeholder = { Text("Enter text to translate...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("source_text_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.End
                        ) {
                            // Paste button
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = clipboard.primaryClip
                                    if (clip != null && clip.itemCount > 0) {
                                        val text = clip.getItemAt(0).text?.toString() ?: ""
                                        if (text.isNotBlank()) {
                                            viewModel.onInputTextChanged(text)
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("paste_button")
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = "Paste text", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            // Source Text-to-Speech pronunciation button
                            if (inputText.isNotBlank()) {
                                val isSpeakingSource = isSpeaking && currentlySpeakingText == inputText
                                IconButton(
                                    onClick = {
                                        val srcCode = if (sourceLang.isAutoDetect) (translationResult?.sourceLangCode ?: "en") else sourceLang.code
                                        viewModel.toggleSpeak(inputText, srcCode, isSlow = false)
                                    },
                                    modifier = Modifier.testTag("tts_source_speak_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = if (isSpeakingSource) "Stop source speech" else "Listen to source pronunciation",
                                        tint = if (isSpeakingSource) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Speech Audio input button (Android SpeechRecognizer API)
                            val isSpeechActive = speechState is SpeechState.Listening || speechState is SpeechState.Ready
                            IconButton(
                                onClick = {
                                    if (isSpeechActive) {
                                        viewModel.stopVoiceInput()
                                    } else {
                                        if (hasAudioPermission) {
                                            viewModel.startSpeechToTextInput()
                                        } else {
                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("voice_input_button")
                            ) {
                                Icon(
                                    imageVector = if (isSpeechActive) Icons.Default.Clear else Icons.Default.Mic,
                                    contentDescription = "Voice speech input with SpeechRecognizer",
                                    tint = if (isSpeechActive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Quick suggestion chips
            if (inputText.isEmpty()) {
                item {
                    Text(
                        text = "Quick phrases",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val samplePhrases = listOf(
                            "Hello, how are you?",
                            "Where is the bathroom?",
                            "Water",
                            "Thank you very much",
                            "The check please",
                            "Do you speak English?"
                        )
                        items(samplePhrases) { phrase ->
                            SuggestionChip(
                                onClick = { viewModel.onInputTextChanged(phrase) },
                                label = { Text(phrase) }
                            )
                        }
                    }
                }
            }

            // Translated Result Card
            item {
                AnimatedVisibility(
                    visible = translationResult != null && translationResult!!.translatedText.isNotBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    translationResult?.let { res ->
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${targetLang.flagEmoji} ${targetLang.name}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (res.isOfflineResult) {
                                        Text(
                                            text = "Offline pack",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                                            modifier = Modifier.padding(end = 6.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = res.translatedText,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.testTag("translated_text_display")
                                )

                                if (!res.phoneticPronunciation.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = res.phoneticPronunciation,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontStyle = FontStyle.Italic,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Actions row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Audio TTS controls (Normal & Slow speech)
                                    val isSpeakingTarget = isSpeaking && currentlySpeakingText == res.translatedText
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                viewModel.toggleSpeak(res.translatedText, res.targetLangCode, isSlow = false)
                                            },
                                            modifier = Modifier.testTag("tts_speak_button")
                                        ) {
                                            Icon(
                                                Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = if (isSpeakingTarget) "Stop speech" else "Listen to translated pronunciation in ${targetLang.name}",
                                                tint = if (isSpeakingTarget) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }

                                        // Slow speed pronunciation button
                                        IconButton(
                                            onClick = {
                                                viewModel.toggleSpeak(res.translatedText, res.targetLangCode, isSlow = true)
                                            },
                                            modifier = Modifier.testTag("tts_slow_button")
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isSpeakingTarget) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
                                            ) {
                                                Text(
                                                    text = "0.7x",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                    color = if (isSpeakingTarget) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }
                                        }
                                    }

                                    Row {
                                        // Copy
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("Translation", res.translatedText)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.testTag("copy_translation_button")
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy translation", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }

                                        // Fullscreen
                                        IconButton(
                                            onClick = { showFullscreenDialog = true },
                                            modifier = Modifier.testTag("fullscreen_button")
                                        ) {
                                            Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen view", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }

                                        // Share
                                        IconButton(
                                            onClick = {
                                                val sendIntent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(Intent.EXTRA_TEXT, "${res.originalText} -> ${res.translatedText}")
                                                    type = "text/plain"
                                                }
                                                context.startActivity(Intent.createChooser(sendIntent, "Share translation"))
                                            },
                                            modifier = Modifier.testTag("share_translation_button")
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = "Share translation", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Dictionary Entry Card
            translationResult?.dictionaryEntry?.let { entry ->
                item {
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "DICTIONARY",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${entry.word} (${entry.partOfSpeech})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = entry.primaryDefinition,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (entry.synonyms.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Synonyms: ${entry.synonyms.joinToString(", ")}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Quick Mode Jump Cards (Camera OCR & Conversation)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.selectTab(AppTab.CAMERA) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("quick_camera_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Camera OCR", fontSize = 13.sp)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.selectTab(AppTab.CONVERSATION) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("quick_conversation_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Conversation", fontSize = 13.sp)
                    }
                }
            }

            // Recent Translations Section
            if (historyList.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent Translations",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.selectTab(AppTab.SAVED) }) {
                            Text("View All")
                        }
                    }
                }

                items(historyList.take(5), key = { it.id }) { item ->
                    HistoryItemRow(
                        item = item,
                        onItemClick = {
                            viewModel.onInputTextChanged(item.sourceText)
                        },
                        onStarClick = {
                            viewModel.toggleStarred(item)
                        },
                        onSpeakClick = {
                            viewModel.speak(item.translatedText, item.targetLangCode)
                        }
                    )
                }
            }
        }
    }

    // Language Selector Modals
    if (showSourceSelector) {
        LanguageSelectorModal(
            isSelectingSource = true,
            currentSelected = sourceLang,
            offlinePacks = offlinePacks,
            onLanguageSelected = { viewModel.setSourceLang(it) },
            onDismissRequest = { showSourceSelector = false }
        )
    }

    if (showTargetSelector) {
        LanguageSelectorModal(
            isSelectingSource = false,
            currentSelected = targetLang,
            offlinePacks = offlinePacks,
            onLanguageSelected = { viewModel.setTargetLang(it) },
            onDismissRequest = { showTargetSelector = false }
        )
    }

    // Voice-to-Text Speech Recognition Overlay
    VoiceRecognitionOverlay(
        speechState = speechState,
        language = if (sourceLang.isAutoDetect) SupportedLanguages.getByCode("en") else sourceLang,
        onStopListening = { viewModel.stopVoiceInput() },
        onCancel = { viewModel.cancelVoiceInput() },
        onRetry = { viewModel.startSpeechToTextInput() },
        onSamplePhraseSelected = { phrase ->
            viewModel.onInputTextChanged(phrase)
            viewModel.cancelVoiceInput()
        }
    )

    // Fullscreen View Dialog (Large readable card for displaying translations to others)
    if (showFullscreenDialog && translationResult != null) {
        Dialog(
            onDismissRequest = { showFullscreenDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = targetLang.name.uppercase(),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = translationResult!!.translatedText,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!translationResult!!.phoneticPronunciation.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = translationResult!!.phoneticPronunciation!!,
                            style = MaterialTheme.typography.titleLarge,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(40.dp))
                    Button(
                        onClick = { showFullscreenDialog = false },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryItemRow(
    item: TranslationHistoryEntity,
    onItemClick: () -> Unit,
    onStarClick: () -> Unit,
    onSpeakClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick() }
            .testTag("history_item_${item.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.sourceText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.translatedText,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
            }

            IconButton(onClick = onSpeakClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = "Speak",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(onClick = onStarClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (item.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (item.isStarred) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
