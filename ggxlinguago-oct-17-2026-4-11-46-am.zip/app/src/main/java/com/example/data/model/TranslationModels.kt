package com.example.data.model

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLangCode: String,
    val targetLangCode: String,
    val detectedLangName: String? = null,
    val phoneticPronunciation: String? = null,
    val alternativeTranslations: List<String> = emptyList(),
    val dictionaryEntry: DictionaryEntry? = null,
    val isOfflineResult: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class DictionaryEntry(
    val word: String,
    val partOfSpeech: String,
    val primaryDefinition: String,
    val synonyms: List<String> = emptyList(),
    val examples: List<Pair<String, String>> = emptyList() // Original and translation
)

enum class TranslationMode {
    TEXT,
    CAMERA,
    CONVERSATION,
    PHRASEBOOK
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class CameraOcrBox(
    val id: String,
    val originalText: String,
    val translatedText: String,
    val leftNorm: Float, // Normalized 0f..1f
    val topNorm: Float,
    val widthNorm: Float,
    val heightNorm: Float
)

data class PhraseItem(
    val id: Long = 0,
    val category: String,
    val englishText: String,
    val translatedText: String,
    val targetLangCode: String,
    val phonetic: String? = null,
    val isFavorite: Boolean = false
)
