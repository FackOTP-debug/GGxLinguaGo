package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translation_history")
data class TranslationHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sourceText: String,
    val translatedText: String,
    val sourceLangCode: String,
    val targetLangCode: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStarred: Boolean = false,
    val mode: String = "TEXT",
    val phonetic: String? = null
)

@Entity(tableName = "offline_packs")
data class OfflinePackEntity(
    @PrimaryKey
    val langCode: String,
    val name: String,
    val sizeMb: Int,
    val isDownloaded: Boolean = false,
    val isDownloading: Boolean = false,
    val downloadProgress: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_phrases")
data class SavedPhraseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,
    val englishText: String,
    val translatedText: String,
    val targetLangCode: String,
    val phonetic: String? = null,
    val isCustom: Boolean = false,
    val isFavorite: Boolean = false
)

@Entity(tableName = "analytics_events")
data class AnalyticsEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val eventType: String, // TRANSLATE_SUCCESS, CAMERA_SCAN, VOICE_INPUT, PACK_DOWNLOAD
    val sourceLangCode: String,
    val targetLangCode: String,
    val mode: String,
    val isOffline: Boolean,
    val charCount: Int = 0,
    val latencyMs: Long = 0,
    val userRegion: String = "Global",
    val timestamp: Long = System.currentTimeMillis()
)
