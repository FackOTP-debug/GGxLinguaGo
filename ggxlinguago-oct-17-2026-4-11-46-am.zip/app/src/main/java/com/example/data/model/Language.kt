package com.example.data.model

data class Language(
    val code: String,
    val name: String,
    val nativeName: String,
    val flagEmoji: String,
    val isAutoDetect: Boolean = false,
    val isOfflineSupported: Boolean = true,
    val packSizeMb: Int = 38
)

object SupportedLanguages {
    val AUTO_DETECT = Language(
        code = "auto",
        name = "Detect language",
        nativeName = "Auto-detect",
        flagEmoji = "🌐",
        isAutoDetect = true,
        isOfflineSupported = false,
        packSizeMb = 0
    )

    // Complete catalog of 108+ global languages
    val ALL_LANGUAGES: List<Language> = listOf(
        // Major Global Languages
        Language("en", "English", "English", "🇺🇸", packSizeMb = 45),
        Language("es", "Spanish", "Español", "🇪🇸", packSizeMb = 38),
        Language("fr", "French", "Français", "🇫🇷", packSizeMb = 41),
        Language("de", "German", "Deutsch", "🇩🇪", packSizeMb = 44),
        Language("it", "Italian", "Italiano", "🇮🇹", packSizeMb = 36),
        Language("pt", "Portuguese", "Português", "🇧🇷", packSizeMb = 39),
        Language("ru", "Russian", "Русский", "🇷🇺", packSizeMb = 48),
        Language("zh", "Chinese (Simplified)", "中文 (简体)", "🇨🇳", packSizeMb = 54),
        Language("zh-TW", "Chinese (Traditional)", "中文 (繁體)", "🇹🇼", packSizeMb = 54),
        Language("ja", "Japanese", "日本語", "🇯🇵", packSizeMb = 52),
        Language("ko", "Korean", "한국어", "🇰🇷", packSizeMb = 49),
        Language("hi", "Hindi", "हिन्दी", "🇮🇳", packSizeMb = 43),
        Language("ar", "Arabic", "العربية", "🇸🇦", packSizeMb = 46),
        Language("bn", "Bengali", "বাংলা", "🇧🇩", packSizeMb = 40),
        Language("tr", "Turkish", "Türkçe", "🇹🇷", packSizeMb = 37),
        Language("vi", "Vietnamese", "Tiếng Việt", "🇻🇳", packSizeMb = 35),
        Language("th", "Thai", "ไทย", "🇹🇭", packSizeMb = 42),
        Language("nl", "Dutch", "Nederlands", "🇳🇱", packSizeMb = 34),
        Language("pl", "Polish", "Polski", "🇵🇱", packSizeMb = 38),
        Language("id", "Indonesian", "Bahasa Indonesia", "🇮🇩", packSizeMb = 33),
        Language("uk", "Ukrainian", "Українська", "🇺🇦", packSizeMb = 44),
        Language("el", "Greek", "Ελληνικά", "🇬🇷", packSizeMb = 40),
        Language("he", "Hebrew", "עברית", "🇮🇱", packSizeMb = 37),
        Language("sv", "Swedish", "Svenska", "🇸🇪", packSizeMb = 32),
        Language("fil", "Filipino (Tagalog)", "Tagalog", "🇵🇭", packSizeMb = 31),
        Language("cs", "Czech", "Čeština", "🇨🇿", packSizeMb = 36),
        Language("ro", "Romanian", "Română", "🇷🇴", packSizeMb = 37),
        Language("hu", "Hungarian", "Magyar", "🇭🇺", packSizeMb = 38),
        Language("da", "Danish", "Dansk", "🇩🇰", packSizeMb = 33),
        Language("fi", "Finnish", "Suomi", "🇫🇮", packSizeMb = 35),
        Language("no", "Norwegian", "Norsk", "🇳🇴", packSizeMb = 33),
        Language("ms", "Malay", "Bahasa Melayu", "🇲🇾", packSizeMb = 34),
        Language("fa", "Persian (Farsi)", "فارسی", "🇮🇷", packSizeMb = 41),
        Language("ur", "Urdu", "اردو", "🇵🇰", packSizeMb = 42),

        // South Asian Languages
        Language("ta", "Tamil", "தமிழ்", "🇮🇳", packSizeMb = 41),
        Language("te", "Telugu", "తెలుగు", "🇮🇳", packSizeMb = 41),
        Language("mr", "Marathi", "मराठी", "🇮🇳", packSizeMb = 40),
        Language("gu", "Gujarati", "ગુજરાતી", "🇮🇳", packSizeMb = 39),
        Language("kn", "Kannada", "ಕನ್ನಡ", "🇮🇳", packSizeMb = 40),
        Language("ml", "Malayalam", "മലയാളം", "🇮🇳", packSizeMb = 42),
        Language("pa", "Punjabi", "ਪੰਜਾਬੀ", "🇮🇳", packSizeMb = 39),
        Language("ne", "Nepali", "नेपाली", "🇳🇵", packSizeMb = 38),
        Language("si", "Sinhala", "සිංහල", "🇱🇰", packSizeMb = 40),
        Language("sd", "Sindhi", "سنڌي", "🇵🇰", packSizeMb = 38),
        Language("or", "Odia", "ଓଡ଼ିଆ", "🇮🇳", packSizeMb = 37),
        Language("as", "Assamese", "অসমীয়া", "🇮🇳", packSizeMb = 36),
        Language("sa", "Sanskrit", "संस्कृतम्", "🇮🇳", packSizeMb = 35),

        // Southeast Asian & Pacific Languages
        Language("my", "Burmese", "မြန်မာဘာသာ", "🇲🇲", packSizeMb = 42),
        Language("km", "Khmer", "ភាសាខ្មែរ", "🇰🇭", packSizeMb = 41),
        Language("lo", "Lao", "ພາສາລາວ", "🇱🇦", packSizeMb = 39),
        Language("ceb", "Cebuano", "Bisaya", "🇵🇭", packSizeMb = 31),
        Language("jv", "Javanese", "Basa Jawa", "🇮🇩", packSizeMb = 33),
        Language("su", "Sundanese", "Basa Sunda", "🇮🇩", packSizeMb = 32),
        Language("hmn", "Hmong", "Hmoob", "🇱🇦", packSizeMb = 29),
        Language("mi", "Maori", "Te Reo Māori", "🇳🇿", packSizeMb = 30),
        Language("sm", "Samoan", "Gagana Sāmoa", "🇼🇸", packSizeMb = 28),
        Language("haw", "Hawaiian", "ʻŌlelo Hawaiʻi", "🇺🇸", packSizeMb = 27),

        // African Languages
        Language("sw", "Swahili", "Kiswahili", "🇰🇪", packSizeMb = 35),
        Language("am", "Amharic", "አማርኛ", "🇪🇹", packSizeMb = 41),
        Language("yo", "Yoruba", "Èdè Yorùbá", "🇳🇬", packSizeMb = 34),
        Language("ig", "Igbo", "Asụsụ Igbo", "🇳🇬", packSizeMb = 33),
        Language("ha", "Hausa", "Harshen Hausa", "🇳🇬", packSizeMb = 36),
        Language("zu", "Zulu", "isiZulu", "🇿🇦", packSizeMb = 35),
        Language("xh", "Xhosa", "isiXhosa", "🇿🇦", packSizeMb = 34),
        Language("af", "Afrikaans", "Afrikaans", "🇿🇦", packSizeMb = 32),
        Language("so", "Somali", "Soomaaliga", "🇸🇴", packSizeMb = 33),
        Language("mg", "Malagasy", "Fiteny Malagasy", "🇲🇬", packSizeMb = 31),
        Language("rw", "Kinyarwanda", "Ikinyarwanda", "🇷🇼", packSizeMb = 32),
        Language("sn", "Shona", "chiShona", "🇿🇼", packSizeMb = 30),
        Language("om", "Oromo", "Afaan Oromoo", "🇪🇹", packSizeMb = 33),
        Language("ti", "Tigrinya", "ትግርኛ", "🇪🇷", packSizeMb = 34),

        // European Languages
        Language("sk", "Slovak", "Slovenčina", "🇸🇰", packSizeMb = 36),
        Language("bg", "Bulgarian", "Български", "🇧🇬", packSizeMb = 39),
        Language("hr", "Croatian", "Hrvatski", "🇭🇷", packSizeMb = 36),
        Language("sr", "Serbian", "Српски", "🇷🇸", packSizeMb = 39),
        Language("sl", "Slovenian", "Slovenščina", "🇸🇮", packSizeMb = 35),
        Language("lt", "Lithuanian", "Lietuvių", "🇱🇹", packSizeMb = 36),
        Language("lv", "Latvian", "Latviešu", "🇱🇻", packSizeMb = 35),
        Language("et", "Estonian", "Eesti", "🇪🇪", packSizeMb = 34),
        Language("sq", "Albanian", "Shqip", "🇦🇱", packSizeMb = 35),
        Language("mk", "Macedonian", "Македонски", "🇲🇰", packSizeMb = 37),
        Language("bs", "Bosnian", "Bosanski", "🇧🇦", packSizeMb = 36),
        Language("is", "Icelandic", "Íslenska", "🇮🇸", packSizeMb = 36),
        Language("ga", "Irish", "Gaeilge", "🇮🇪", packSizeMb = 33),
        Language("cy", "Welsh", "Cymraeg", "🏴󠁧󠁢󠁷󠁬󠁳󠁿", packSizeMb = 33),
        Language("gd", "Scottish Gaelic", "Gàidhlig", "🏴󠁧󠁢󠁳󠁣󠁴󠁿", packSizeMb = 31),
        Language("eu", "Basque", "Euskara", "🇪🇸", packSizeMb = 34),
        Language("ca", "Catalan", "Català", "🇦🇩", packSizeMb = 35),
        Language("gl", "Galician", "Galego", "🇪🇸", packSizeMb = 34),
        Language("mt", "Maltese", "Malti", "🇲🇹", packSizeMb = 32),
        Language("lb", "Luxembourgish", "Lëtzebuergesch", "🇱🇺", packSizeMb = 31),
        Language("co", "Corsican", "Corsu", "🇫🇷", packSizeMb = 29),
        Language("fy", "Frisian", "Frysk", "🇳🇱", packSizeMb = 30),
        Language("la", "Latin", "Latina", "🇻🇦", packSizeMb = 31),
        Language("eo", "Esperanto", "Esperanto", "🌐", packSizeMb = 28),
        Language("yi", "Yiddish", "ייִדיש", "🇮🇱", packSizeMb = 35),

        // Central & Western Asian Languages
        Language("ka", "Georgian", "ქართული", "🇬🇪", packSizeMb = 40),
        Language("hy", "Armenian", "Հայերեն", "🇦🇲", packSizeMb = 39),
        Language("az", "Azerbaijani", "Azərbaycan", "🇦🇿", packSizeMb = 37),
        Language("kk", "Kazakh", "Қазақ тілі", "🇰🇿", packSizeMb = 41),
        Language("uz", "Uzbek", "Oʻzbekcha", "🇺🇿", packSizeMb = 37),
        Language("mn", "Mongolian", "Монгол", "🇲🇳", packSizeMb = 40),
        Language("ky", "Kyrgyz", "Кыргызча", "🇰🇬", packSizeMb = 38),
        Language("tg", "Tajik", "Тоҷикӣ", "🇹🇯", packSizeMb = 37),
        Language("ps", "Pashto", "پښتو", "🇦🇫", packSizeMb = 39),
        Language("ku", "Kurdish", "Kurdî", "🇮🇶", packSizeMb = 38),
        Language("tt", "Tatar", "Татарча", "🇷🇺", packSizeMb = 36),
        Language("ug", "Uyghur", "ئۇيغۇرچە", "🇨🇳", packSizeMb = 39)
    )

    fun getByCode(code: String): Language {
        if (code == "auto") return AUTO_DETECT
        return ALL_LANGUAGES.find { it.code.equals(code, ignoreCase = true) }
            ?: Language(code, code.uppercase(), code.uppercase(), "🌐")
    }
}
