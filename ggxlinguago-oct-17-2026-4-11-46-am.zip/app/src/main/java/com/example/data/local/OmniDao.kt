package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OmniDao {
    // History
    @Query("SELECT * FROM translation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<TranslationHistoryEntity>>

    @Query("SELECT * FROM translation_history WHERE isStarred = 1 ORDER BY timestamp DESC")
    fun getStarredHistory(): Flow<List<TranslationHistoryEntity>>

    @Query("SELECT * FROM translation_history WHERE sourceText LIKE '%' || :query || '%' OR translatedText LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchHistory(query: String): Flow<List<TranslationHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: TranslationHistoryEntity): Long

    @Query("UPDATE translation_history SET isStarred = :isStarred WHERE id = :id")
    suspend fun updateStarred(id: Long, isStarred: Boolean)

    @Query("DELETE FROM translation_history WHERE id = :id")
    suspend fun deleteHistory(id: Long)

    @Query("DELETE FROM translation_history")
    suspend fun clearHistory()

    // Offline Language Packs
    @Query("SELECT * FROM offline_packs ORDER BY name ASC")
    fun getAllPacks(): Flow<List<OfflinePackEntity>>

    @Query("SELECT * FROM offline_packs WHERE langCode = :langCode LIMIT 1")
    suspend fun getPackByLang(langCode: String): OfflinePackEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePack(pack: OfflinePackEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPacksInitial(packs: List<OfflinePackEntity>)

    @Query("UPDATE offline_packs SET isDownloading = :isDownloading, downloadProgress = :progress WHERE langCode = :langCode")
    suspend fun updatePackProgress(langCode: String, isDownloading: Boolean, progress: Int)

    @Query("UPDATE offline_packs SET isDownloaded = :isDownloaded, isDownloading = 0, downloadProgress = 100 WHERE langCode = :langCode")
    suspend fun setPackDownloaded(langCode: String, isDownloaded: Boolean)

    // Saved Phrases & Offline Reading Mode
    @Query("SELECT * FROM saved_phrases WHERE targetLangCode = :langCode ORDER BY category ASC, id ASC")
    fun getPhrasesForLang(langCode: String): Flow<List<SavedPhraseEntity>>

    @Query("SELECT * FROM saved_phrases WHERE targetLangCode = :langCode AND category = :category ORDER BY id ASC")
    fun getPhrasesByCategory(langCode: String, category: String): Flow<List<SavedPhraseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhrase(phrase: SavedPhraseEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPhrasesInitial(phrases: List<SavedPhraseEntity>)

    @Query("UPDATE saved_phrases SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updatePhraseFavorite(id: Long, isFavorite: Boolean)

    // Analytics
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalyticsEvent(event: AnalyticsEventEntity)

    @Query("SELECT * FROM analytics_events ORDER BY timestamp DESC LIMIT 200")
    fun getRecentAnalytics(): Flow<List<AnalyticsEventEntity>>

    @Query("SELECT COUNT(*) FROM analytics_events")
    suspend fun getTotalTranslationsCount(): Int

    @Query("SELECT COUNT(*) FROM analytics_events WHERE isOffline = 1")
    suspend fun getOfflineTranslationsCount(): Int
}
