package com.example.data.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface SpeechState {
    object Idle : SpeechState
    data class Ready(val langCode: String) : SpeechState
    data class Listening(val rmsDb: Float = 0f, val partialText: String = "") : SpeechState
    data class Success(val text: String) : SpeechState
    data class Error(val message: String, val errorCode: Int) : SpeechState
}

class SpeechRecognizerManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    private val _speechState = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val speechState: StateFlow<SpeechState> = _speechState.asStateFlow()

    private var onResultCallback: ((String) -> Unit)? = null

    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun startListening(
        langCode: String = "en",
        onResult: (String) -> Unit
    ) {
        this.onResultCallback = onResult

        mainHandler.post {
            try {
                // Cancel existing session
                stopListeningInternal()

                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    _speechState.value = SpeechState.Error(
                        message = "Speech recognition is not supported on this device.",
                        errorCode = -1
                    )
                    return@post
                }

                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createListener(langCode))
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    val locale = getSpeechLocale(langCode)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale.toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }

                _speechState.value = SpeechState.Ready(langCode)
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("SpeechRecognizerManager", "Failed to start speech recognizer", e)
                _speechState.value = SpeechState.Error(
                    message = e.localizedMessage ?: "Failed to start speech recognition",
                    errorCode = -1
                )
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.e("SpeechRecognizerManager", "Error stopping listening", e)
            }
        }
    }

    fun cancel() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                _speechState.value = SpeechState.Idle
            } catch (e: Exception) {
                Log.e("SpeechRecognizerManager", "Error canceling speech", e)
            }
        }
    }

    private fun stopListeningInternal() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            // Ignored
        }
    }

    private fun createListener(langCode: String): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _speechState.value = SpeechState.Listening(rmsDb = 0f, partialText = "")
            }

            override fun onBeginningOfSpeech() {
                _speechState.value = SpeechState.Listening(rmsDb = 2f, partialText = "")
            }

            override fun onRmsChanged(rmsdB: Float) {
                val current = _speechState.value
                val partial = if (current is SpeechState.Listening) current.partialText else ""
                _speechState.value = SpeechState.Listening(rmsDb = rmsdB, partialText = partial)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                val current = _speechState.value
                val partial = if (current is SpeechState.Listening) current.partialText else ""
                _speechState.value = SpeechState.Listening(rmsDb = 0f, partialText = partial)
            }

            override fun onError(error: Int) {
                val errorMsg = mapErrorCode(error)
                _speechState.value = SpeechState.Error(message = errorMsg, errorCode = error)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognizedText = matches?.firstOrNull()?.trim() ?: ""

                if (recognizedText.isNotEmpty()) {
                    _speechState.value = SpeechState.Success(recognizedText)
                    onResultCallback?.invoke(recognizedText)
                } else {
                    _speechState.value = SpeechState.Error(
                        message = "No speech detected. Please speak clearly.",
                        errorCode = SpeechRecognizer.ERROR_NO_MATCH
                    )
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull() ?: ""
                val currentRms = (_speechState.value as? SpeechState.Listening)?.rmsDb ?: 0f
                _speechState.value = SpeechState.Listening(rmsDb = currentRms, partialText = partial)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun mapErrorCode(error: Int): String {
        return when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Speech recognition client error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required"
            SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out"
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try speaking again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy. Please try again."
            SpeechRecognizer.ERROR_SERVER -> "Speech server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input detected"
            else -> "Speech recognition error ($error)"
        }
    }

    private fun getSpeechLocale(langCode: String): Locale {
        return when (langCode.lowercase()) {
            "en" -> Locale.US
            "es" -> Locale("es", "ES")
            "fr" -> Locale.FRANCE
            "de" -> Locale.GERMANY
            "it" -> Locale.ITALY
            "pt" -> Locale("pt", "BR")
            "ru" -> Locale("ru", "RU")
            "zh", "zh-cn" -> Locale.SIMPLIFIED_CHINESE
            "zh-tw" -> Locale.TRADITIONAL_CHINESE
            "ja" -> Locale.JAPAN
            "ko" -> Locale.KOREA
            "hi" -> Locale("hi", "IN")
            "ar" -> Locale("ar")
            "tr" -> Locale("tr", "TR")
            "vi" -> Locale("vi", "VN")
            "th" -> Locale("th", "TH")
            "nl" -> Locale("nl", "NL")
            "pl" -> Locale("pl", "PL")
            "id" -> Locale("id", "ID")
            else -> Locale(langCode)
        }
    }

    fun destroy() {
        mainHandler.post {
            stopListeningInternal()
            _speechState.value = SpeechState.Idle
        }
    }
}
