package com.example.data.engine

import com.example.data.model.DictionaryEntry
import com.example.data.model.SupportedLanguages

object OfflineDictionaryEngine {

    // Multilingual common terms mapping: term -> (targetLangCode -> Pair(translation, phonetic))
    private val MULTI_LANG_VOCAB: Map<String, Map<String, Pair<String, String?>>> = mapOf(
        "hello" to mapOf(
            "es" to Pair("hola", "OH-lah"),
            "fr" to Pair("bonjour", "bohn-zhoor"),
            "de" to Pair("hallo", "HAH-loh"),
            "it" to Pair("ciao", "chow"),
            "pt" to Pair("olá", "oh-LAH"),
            "ru" to Pair("здравствуйте", "ZDRAHST-vuy-tye"),
            "zh" to Pair("你好", "Nǐ hǎo"),
            "zh-TW" to Pair("你好", "Nǐ hǎo"),
            "ja" to Pair("こんにちは", "Konnichiwa"),
            "ko" to Pair("안녕하세요", "Annyeonghaseyo"),
            "hi" to Pair("नमस्ते", "Namaste"),
            "ar" to Pair("مرحبا", "Marhaban"),
            "bn" to Pair("হ্যালো", "Hyālō"),
            "tr" to Pair("merhaba", "mehr-hah-bah"),
            "vi" to Pair("xin chào", "sin chow"),
            "th" to Pair("สวัสดี", "Sawasdee"),
            "nl" to Pair("hallo", "HAH-loh"),
            "pl" to Pair("cześć", "cheshch"),
            "id" to Pair("halo", "hah-loh"),
            "uk" to Pair("привіт", "pryvit"),
            "el" to Pair("γειά σου", "Yassou"),
            "he" to Pair("שלום", "Shalom"),
            "sv" to Pair("hej", "hey"),
            "fil" to Pair("kamusta", "kah-moos-TAH"),
            "cs" to Pair("ahoj", "ah-hoy"),
            "ro" to Pair("salut", "sah-loot"),
            "hu" to Pair("szia", "see-ah"),
            "da" to Pair("hej", "hey"),
            "fi" to Pair("hei", "hey"),
            "no" to Pair("hei", "hey"),
            "ms" to Pair("halo", "hah-loh"),
            "fa" to Pair("سلام", "Salam"),
            "ur" to Pair("ہیلو", "Hello"),
            "ta" to Pair("வணக்கம்", "Vanakkam"),
            "te" to Pair("నమస్కారం", "Namaskaram"),
            "mr" to Pair("नमस्कार", "Namaskar"),
            "gu" to Pair("નમસ્તે", "Namaste"),
            "kn" to Pair("ನಮಸ್ಕಾರ", "Namaskara"),
            "ml" to Pair("നമസ്കാരം", "Namaskaram"),
            "pa" to Pair("ਸਤਿ ਸ਼੍ਰੀ ਅਕਾਲ", "Sat Sri Akaal"),
            "ne" to Pair("नमस्ते", "Namaste"),
            "si" to Pair("ආයුබෝවන්", "Ayubowan"),
            "my" to Pair("မင်္ဂလာပါ", "Mingalaba"),
            "km" to Pair("សួស្តី", "Sousdey"),
            "lo" to Pair("ສະບາຍດີ", "Sabaidee"),
            "sw" to Pair("jambo", "JAHM-boh"),
            "am" to Pair("ሰላም", "Selam"),
            "yo" to Pair("ẹ n lẹ", "ehn-leh"),
            "ig" to Pair("ndewo", "n-deh-woh"),
            "ha" to Pair("sannu", "sahn-noo"),
            "zu" to Pair("sawubona", "sah-woo-BOH-nah"),
            "xh" to Pair("molo", "MOH-loh"),
            "af" to Pair("hallo", "HAH-loh"),
            "so" to Pair("nabad", "nah-BAHD"),
            "mg" to Pair("manao ahoana", "mah-now ow-nah"),
            "sk" to Pair("ahoj", "ah-hoy"),
            "bg" to Pair("здравейте", "zdravéyte"),
            "hr" to Pair("bok", "bohk"),
            "sr" to Pair("здраво", "zdravo"),
            "sl" to Pair("zdravo", "zdrah-voh"),
            "lt" to Pair("labas", "lah-bahs"),
            "lv" to Pair("sveiki", "svay-kee"),
            "et" to Pair("tere", "teh-reh"),
            "sq" to Pair("përshëndetje", "per-shen-det-ye"),
            "mk" to Pair("здраво", "zdravo"),
            "bs" to Pair("zdravo", "zdrah-voh"),
            "is" to Pair("halló", "haht-loh"),
            "ga" to Pair("dia dhuit", "dee-ah gwit"),
            "cy" to Pair("helo", "HEH-loh"),
            "gd" to Pair("halò", "hah-loh"),
            "eu" to Pair("kaixo", "KYE-shoh"),
            "ca" to Pair("hola", "OH-lah"),
            "gl" to Pair("ola", "OH-lah"),
            "mt" to Pair("bongu", "bon-zhoo"),
            "ka" to Pair("გამარჯობა", "Gamarjoba"),
            "hy" to Pair("բարև", "Barev"),
            "az" to Pair("salam", "sah-lahm"),
            "kk" to Pair("сәлеметсіз бе", "Salemetsiz be"),
            "uz" to Pair("salom", "sah-lom"),
            "mn" to Pair("сайн байна уу", "Sain baina uu"),
            "eo" to Pair("saluton", "sah-LOO-tohn"),
            "la" to Pair("salve", "SAHL-weh")
        ),
        "thank you" to mapOf(
            "es" to Pair("gracias", "GRAH-syahs"),
            "fr" to Pair("merci", "mehr-see"),
            "de" to Pair("danke", "DAHN-keh"),
            "it" to Pair("grazie", "GRAHT-syeh"),
            "pt" to Pair("obrigado", "oh-bree-GAH-doo"),
            "ru" to Pair("спасибо", "spah-SEE-bah"),
            "zh" to Pair("谢谢", "Xièxiè"),
            "zh-TW" to Pair("謝謝", "Xièxiè"),
            "ja" to Pair("ありがとうございます", "Arigatō gozaimasu"),
            "ko" to Pair("감사합니다", "Gamsahamnida"),
            "hi" to Pair("धन्यवाद", "Dhanyavaad"),
            "ar" to Pair("شكرا", "Shukran"),
            "bn" to Pair("ধন্যবাদ", "Dhonnobaad"),
            "tr" to Pair("teşekkür ederim", "teh-sheh-koor"),
            "vi" to Pair("cảm ơn", "kahm uhn"),
            "th" to Pair("ขอบคุณ", "Khop khun"),
            "nl" to Pair("dank je", "dahnk yuh"),
            "pl" to Pair("dziękuję", "jen-KOO-yeh"),
            "id" to Pair("terima kasih", "teh-REE-mah KAH-see"),
            "uk" to Pair("дякую", "dyakuyu"),
            "el" to Pair("ευχαριστώ", "Efcharisto"),
            "he" to Pair("תודה", "Toda"),
            "sv" to Pair("tack", "tahk"),
            "fil" to Pair("salamat", "sah-LAH-maht"),
            "cs" to Pair("děkuji", "DYEH-koo-yee"),
            "ro" to Pair("mulțumesc", "mool-tsoo-MESK"),
            "hu" to Pair("köszönöm", "KUH-suh-nuhm"),
            "da" to Pair("tak", "tahk"),
            "fi" to Pair("kiitos", "KEE-tohs"),
            "no" to Pair("takk", "tahk"),
            "ms" to Pair("terima kasih", "teh-ree-mah kah-see"),
            "fa" to Pair("متشکرم", "Motashakkeram"),
            "ur" to Pair("شکریہ", "Shukriya"),
            "ta" to Pair("நன்றி", "Nandri"),
            "te" to Pair("ధన్యవాదాలు", "Dhanyavadalu"),
            "sw" to Pair("asante", "ah-SAHN-teh"),
            "am" to Pair("አመሰግናለሁ", "Ameseginalehu"),
            "zu" to Pair("ngiyabonga", "ng-ee-yah-BOHN-gah"),
            "af" to Pair("dankie", "DAHN-kee"),
            "eo" to Pair("dankon", "DAHN-kohn"),
            "la" to Pair("gratias tibi", "GRAH-tee-ahs")
        ),
        "please" to mapOf(
            "es" to Pair("por favor", "por fah-VOR"),
            "fr" to Pair("s'il vous plaît", "seel voo pleh"),
            "de" to Pair("bitte", "BIT-teh"),
            "it" to Pair("per favore", "pehr fah-VOH-reh"),
            "pt" to Pair("por favor", "poor fah-VOHR"),
            "ru" to Pair("пожалуйста", "pah-ZHAH-luy-stah"),
            "zh" to Pair("请", "Qǐng"),
            "ja" to Pair("お願いします", "Onegaishimasu"),
            "ko" to Pair("부탁합니다", "Butakhamnida"),
            "hi" to Pair("कृपया", "Kripya"),
            "ar" to Pair("من فضلك", "Min fadlik"),
            "tr" to Pair("lütfen", "LOOT-fehn"),
            "vi" to Pair("làm ơn", "lahm uhn"),
            "th" to Pair("โปรด", "Prohd"),
            "nl" to Pair("alstublieft", "ahl-stoo-BLEEFT"),
            "pl" to Pair("proszę", "PROH-sheh"),
            "id" to Pair("tolong", "TOH-lohng"),
            "sw" to Pair("tafadhali", "tah-fah-DHAH-lee"),
            "af" to Pair("asseblief", "ah-seh-BLEEF")
        ),
        "yes" to mapOf(
            "es" to Pair("sí", "see"),
            "fr" to Pair("oui", "wee"),
            "de" to Pair("ja", "yah"),
            "it" to Pair("sì", "see"),
            "pt" to Pair("sim", "seem"),
            "ru" to Pair("да", "dah"),
            "zh" to Pair("是的", "Shì de"),
            "ja" to Pair("はい", "Hai"),
            "ko" to Pair("네", "Ne"),
            "hi" to Pair("हाँ", "Haan"),
            "ar" to Pair("نعم", "Na'am"),
            "tr" to Pair("evet", "eh-VEHT"),
            "vi" to Pair("vâng", "vuhng"),
            "th" to Pair("ใช่", "Chai"),
            "nl" to Pair("ja", "yah"),
            "pl" to Pair("tak", "tahk"),
            "id" to Pair("ya", "yah"),
            "sw" to Pair("ndiyo", "n-DEE-yoh")
        ),
        "no" to mapOf(
            "es" to Pair("no", "noh"),
            "fr" to Pair("non", "nohn"),
            "de" to Pair("nein", "nine"),
            "it" to Pair("no", "noh"),
            "pt" to Pair("não", "nowng"),
            "ru" to Pair("нет", "nyet"),
            "zh" to Pair("不是", "Bù shì"),
            "ja" to Pair("いいえ", "Iie"),
            "ko" to Pair("아니오", "Anio"),
            "hi" to Pair("नहीं", "Nahin"),
            "ar" to Pair("لا", "Laa"),
            "tr" to Pair("hayır", "HYE-uhr"),
            "vi" to Pair("không", "khom"),
            "th" to Pair("ไม่ใช่", "Mai chai"),
            "nl" to Pair("nee", "nay"),
            "pl" to Pair("nie", "nyeh"),
            "id" to Pair("tidak", "TEE-dahk"),
            "sw" to Pair("hapana", "hah-PAH-nah")
        ),
        "water" to mapOf(
            "es" to Pair("agua", "AH-gwah"),
            "fr" to Pair("eau", "oh"),
            "de" to Pair("wasser", "VAHS-ser"),
            "it" to Pair("acqua", "AHK-wah"),
            "pt" to Pair("água", "AH-gwah"),
            "ru" to Pair("вода", "vah-DAH"),
            "zh" to Pair("水", "Shuǐ"),
            "ja" to Pair("水", "Mizu"),
            "ko" to Pair("물", "Mul"),
            "hi" to Pair("पानी", "Paani"),
            "ar" to Pair("ماء", "Maa'"),
            "tr" to Pair("su", "soo"),
            "vi" to Pair("nước", "nuh-uhk"),
            "th" to Pair("น้ำ", "Nam"),
            "nl" to Pair("water", "VAH-tuhr"),
            "pl" to Pair("woda", "VOH-dah"),
            "id" to Pair("air", "ah-eer"),
            "sw" to Pair("maji", "MAH-jee")
        ),
        "goodbye" to mapOf(
            "es" to Pair("adiós", "ah-DYOHS"),
            "fr" to Pair("au revoir", "oh ruh-vwahr"),
            "de" to Pair("auf wiedersehen", "owf VEE-der-zayn"),
            "it" to Pair("arrivederci", "ah-ree-veh-DEHR-chee"),
            "pt" to Pair("adeus", "ah-DAY-oosh"),
            "ru" to Pair("до свидания", "dah svi-DAH-nya"),
            "zh" to Pair("再见", "Zàijiàn"),
            "ja" to Pair("さようなら", "Sayōnara"),
            "ko" to Pair("안녕히 계세요", "Annyeonghi gyeseyo"),
            "hi" to Pair("अलविदा", "Alvida"),
            "ar" to Pair("مع السلامة", "Ma'a as-salaama"),
            "tr" to Pair("hoşça kal", "HOSH-chah kahl"),
            "sw" to Pair("kwaheri", "kwah-HEH-ree")
        )
    )

    fun lookup(query: String, sourceLang: String, targetLang: String): Pair<String, String?>? {
        val clean = query.trim().lowercase()

        // 1. Direct english source lookup in multi-lingual table
        if (sourceLang == "en") {
            MULTI_LANG_VOCAB[clean]?.get(targetLang)?.let { return it }
        }

        // 2. Reverse lookup (target is english)
        if (targetLang == "en") {
            MULTI_LANG_VOCAB.forEach { (engWord, langMap) ->
                val match = langMap[sourceLang]
                if (match != null && match.first.equals(clean, ignoreCase = true)) {
                    return Pair(engWord, null)
                }
            }
        }

        // 3. Pivot lookup: Source -> English -> Target
        for ((engWord, langMap) in MULTI_LANG_VOCAB) {
            val srcMatch = langMap[sourceLang]
            if (srcMatch != null && srcMatch.first.equals(clean, ignoreCase = true)) {
                langMap[targetLang]?.let { return it }
                return Pair(engWord, null)
            }
        }

        return null
    }

    fun getDictionaryEntry(word: String): DictionaryEntry? {
        val clean = word.trim().lowercase()
        return when (clean) {
            "hello", "hi" -> DictionaryEntry(
                word = "hello",
                partOfSpeech = "greeting / exclamation",
                primaryDefinition = "Used as a greeting or to begin a phone conversation.",
                synonyms = listOf("hi", "greetings", "salutations", "welcome", "good day"),
                examples = listOf(
                    "Hello, how are you today?" to "Hola, ¿cómo estás hoy?",
                    "She said hello to the group." to "Ella saludó al grupo."
                )
            )
            "water" -> DictionaryEntry(
                word = "water",
                partOfSpeech = "noun",
                primaryDefinition = "A transparent, odorless liquid vital for life, covering 71% of Earth's surface.",
                synonyms = listOf("H2O", "liquid", "drink", "aqua"),
                examples = listOf(
                    "Can I please have a glass of water?" to "¿Puedo tomar un vaso de agua, por favor?"
                )
            )
            "thank you", "thanks" -> DictionaryEntry(
                word = "thank you",
                partOfSpeech = "expression / phrase",
                primaryDefinition = "A polite expression of gratitude and appreciation.",
                synonyms = listOf("thanks", "much obliged", "gratitude", "appreciate it"),
                examples = listOf(
                    "Thank you for all your kind help." to "Gracias por toda su amable ayuda."
                )
            )
            else -> null
        }
    }
}
