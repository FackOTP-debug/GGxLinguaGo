package com.example.data.repository

import com.example.data.engine.TranslationEngine
import com.example.data.local.AnalyticsEventEntity
import com.example.data.local.OfflinePackEntity
import com.example.data.local.OmniDao
import com.example.data.local.SavedPhraseEntity
import com.example.data.local.TranslationHistoryEntity
import com.example.data.model.Language
import com.example.data.model.SeedPhrases
import com.example.data.model.SupportedLanguages
import com.example.data.model.ThemeMode
import com.example.data.model.TranslationResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class TranslationRepository(
    private val dao: OmniDao,
    private val appScope: CoroutineScope
) {
    val allHistory: Flow<List<TranslationHistoryEntity>> = dao.getAllHistory()
    val starredHistory: Flow<List<TranslationHistoryEntity>> = dao.getStarredHistory()
    val allPacks: Flow<List<OfflinePackEntity>> = dao.getAllPacks()
    val analyticsEvents: Flow<List<AnalyticsEventEntity>> = dao.getRecentAnalytics()

    private val _isOfflineOnlyMode = MutableStateFlow(false)
    val isOfflineOnlyMode: StateFlow<Boolean> = _isOfflineOnlyMode.asStateFlow()

    private val _isLowEndDeviceMode = MutableStateFlow(false)
    val isLowEndDeviceMode: StateFlow<Boolean> = _isLowEndDeviceMode.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    init {
        appScope.launch(Dispatchers.IO) {
            initializePacksIfNeeded()
            initializePhrasesIfNeeded()
        }
    }

    private suspend fun initializePacksIfNeeded() {
        val initialPacks = SupportedLanguages.ALL_LANGUAGES.map { lang ->
            OfflinePackEntity(
                langCode = lang.code,
                name = lang.name,
                sizeMb = lang.packSizeMb,
                // Default English and Spanish are pre-installed for immediate offline test
                isDownloaded = lang.code == "en" || lang.code == "es",
                isDownloading = false,
                downloadProgress = if (lang.code == "en" || lang.code == "es") 100 else 0
            )
        }
        dao.insertPacksInitial(initialPacks)
    }

    private suspend fun initializePhrasesIfNeeded() {
        dao.insertPhrasesInitial(SeedPhrases.getInitialPhrases("es"))
        dao.insertPhrasesInitial(SeedPhrases.getInitialPhrases("fr"))
    }

    fun getPhrasesForLang(langCode: String): Flow<List<SavedPhraseEntity>> {
        return dao.getPhrasesForLang(langCode)
    }

    fun searchHistory(query: String): Flow<List<TranslationHistoryEntity>> {
        return dao.searchHistory(query)
    }

    suspend fun translate(
        text: String,
        sourceLangCode: String,
        targetLangCode: String,
        mode: String = "TEXT"
    ): TranslationResult {
        val startTime = System.currentTimeMillis()
        val isOffline = _isOfflineOnlyMode.value || isPackDownloaded(targetLangCode)

        val result = TranslationEngine.translate(
            text = text,
            sourceLangCode = sourceLangCode,
            targetLangCode = targetLangCode,
            isOfflineMode = isOffline
        )
        val latency = System.currentTimeMillis() - startTime

        if (text.isNotBlank()) {
            dao.insertHistory(
                TranslationHistoryEntity(
                    sourceText = text,
                    translatedText = result.translatedText,
                    sourceLangCode = result.sourceLangCode,
                    targetLangCode = result.targetLangCode,
                    mode = mode,
                    phonetic = result.phoneticPronunciation
                )
            )

            // Log analytics metric
            val regions = listOf("Latin America", "North America", "Europe", "Asia-Pacific", "Middle East", "Africa")
            dao.insertAnalyticsEvent(
                AnalyticsEventEntity(
                    eventType = "TRANSLATE_SUCCESS",
                    sourceLangCode = result.sourceLangCode,
                    targetLangCode = result.targetLangCode,
                    mode = mode,
                    isOffline = isOffline,
                    charCount = text.length,
                    latencyMs = latency,
                    userRegion = regions[Random.nextInt(regions.size)]
                )
            )
        }

        return result
    }

    suspend fun toggleHistoryStarred(id: Long, currentStarred: Boolean) {
        dao.updateStarred(id, !currentStarred)
    }

    suspend fun deleteHistory(id: Long) {
        dao.deleteHistory(id)
    }

    suspend fun clearAllHistory() {
        dao.clearHistory()
    }

    suspend fun togglePhraseFavorite(id: Long, currentFav: Boolean) {
        dao.updatePhraseFavorite(id, !currentFav)
    }

    suspend fun addCustomPhrase(category: String, english: String, translated: String, langCode: String) {
        dao.insertPhrase(
            SavedPhraseEntity(
                category = category,
                englishText = english,
                translatedText = translated,
                targetLangCode = langCode,
                isCustom = true
            )
        )
    }

    fun downloadPack(langCode: String) {
        appScope.launch(Dispatchers.IO) {
            dao.updatePackProgress(langCode, isDownloading = true, progress = 5)
            // Realistic incremental download simulation for offline packs
            for (p in 10..100 step 15) {
                delay(220)
                dao.updatePackProgress(langCode, isDownloading = true, progress = p)
            }
            dao.setPackDownloaded(langCode, true)
            dao.insertAnalyticsEvent(
                AnalyticsEventEntity(
                    eventType = "PACK_DOWNLOADED",
                    sourceLangCode = "en",
                    targetLangCode = langCode,
                    mode = "OFFLINE",
                    isOffline = true,
                    userRegion = "Global"
                )
            )
        }
    }

    suspend fun removePack(langCode: String) {
        dao.setPackDownloaded(langCode, false)
        dao.updatePackProgress(langCode, isDownloading = false, progress = 0)
    }

    private suspend fun isPackDownloaded(langCode: String): Boolean {
        if (langCode == "en") return true
        val pack = dao.getPackByLang(langCode)
        return pack?.isDownloaded ?: false
    }

    fun setOfflineOnlyMode(enabled: Boolean) {
        _isOfflineOnlyMode.value = enabled
    }

    fun setLowEndDeviceMode(enabled: Boolean) {
        _isLowEndDeviceMode.value = enabled
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }
}
