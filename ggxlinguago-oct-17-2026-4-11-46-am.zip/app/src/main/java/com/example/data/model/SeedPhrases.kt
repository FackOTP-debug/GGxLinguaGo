package com.example.data.model

import com.example.data.local.SavedPhraseEntity

object SeedPhrases {
    fun getInitialPhrases(targetLang: String = "es"): List<SavedPhraseEntity> {
        val phrases = mutableListOf<SavedPhraseEntity>()

        // Essentials
        phrases.add(SavedPhraseEntity(
            category = "Essentials",
            englishText = "Hello / Good day",
            translatedText = if (targetLang == "es") "Hola / Buenos días" else "Bonjour",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "OH-lah / BWEH-nohs DEE-ahs" else "bohn-zhoor"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Essentials",
            englishText = "Please",
            translatedText = if (targetLang == "es") "Por favor" else "S'il vous plaît",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "por fah-VOR" else "seel voo pleh"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Essentials",
            englishText = "Thank you very much",
            translatedText = if (targetLang == "es") "Muchas gracias" else "Merci beaucoup",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "MOO-chahs GRAH-syahs" else "mehr-see boh-koo"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Essentials",
            englishText = "Do you speak English?",
            translatedText = if (targetLang == "es") "¿Habla inglés?" else "Parlez-vous anglais ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "AH-blah een-GLEHS" else "par-lay voo ahn-glay"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Essentials",
            englishText = "I don't understand",
            translatedText = if (targetLang == "es") "No entiendo" else "Je ne comprends pas",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "noh ehn-TYEHN-doh" else "zhuh nuh kohm-prahn pah"
        ))

        // Travel & Transport
        phrases.add(SavedPhraseEntity(
            category = "Travel",
            englishText = "Where is the train station?",
            translatedText = if (targetLang == "es") "¿Dónde está la estación de tren?" else "Où est la gare ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "DOHN-deh ehs-TAH lah ehs-tah-SYOHN deh trehn" else "oo eh lah gahr"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Travel",
            englishText = "How much is a ticket to the airport?",
            translatedText = if (targetLang == "es") "¿Cuánto cuesta un boleto al aeropuerto?" else "Combien coûte un billet pour l'aéroport ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "KWAHN-toh KWEHS-tah oon boh-LEH-toh" else "kohm-byan koot un bee-yay"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Travel",
            englishText = "Where is the nearest bathroom?",
            translatedText = if (targetLang == "es") "¿Dónde está el baño más cercano?" else "Où sont les toilettes les plus proches ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "DOHN-deh ehs-TAH ehl BAHN-yoh mahs sehr-KAH-noh" else "oo sohn lay twah-let"
        ))

        // Dining & Food
        phrases.add(SavedPhraseEntity(
            category = "Dining",
            englishText = "A table for two, please",
            translatedText = if (targetLang == "es") "Una mesa para dos, por favor" else "Une table pour deux, s'il vous plaît",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "OO-nah MEH-sah PAH-rah dohs" else "oon tahbl poor duh"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Dining",
            englishText = "Could I have the menu and water?",
            translatedText = if (targetLang == "es") "¿Me trae el menú y agua?" else "Puis-je avoir le menu et de l'eau ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "meh TRAH-eh ehl meh-NOO ee AH-gwah" else null
        ))
        phrases.add(SavedPhraseEntity(
            category = "Dining",
            englishText = "The bill, please",
            translatedText = if (targetLang == "es") "La cuenta, por favor" else "L'addition, s'il vous plaît",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "lah KWEHN-tah por fah-VOR" else "lah-dee-syohn"
        ))

        // Emergency
        phrases.add(SavedPhraseEntity(
            category = "Emergency",
            englishText = "Please help me!",
            translatedText = if (targetLang == "es") "¡Por favor, ayúdeme!" else "Aidez-moi s'il vous plaît !",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "por fah-VOR ah-YOO-deh-meh" else "eh-day mwah"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Emergency",
            englishText = "Where is the nearest hospital?",
            translatedText = if (targetLang == "es") "¿Dónde está el hospital más cercano?" else "Où est l'hôpital le plus proche ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "DOHN-deh ehs-TAH ehl ohs-pee-TAHL" else "oo eh loh-pee-tahl"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Emergency",
            englishText = "Call an ambulance / police",
            translatedText = if (targetLang == "es") "Llame a una ambulancia / policía" else "Appelez une ambulance / la police",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "YAH-meh ah OO-nah ahm-boo-LAHN-syah" else "ah-play oon ahm-boo-lahns"
        ))

        // Shopping
        phrases.add(SavedPhraseEntity(
            category = "Shopping",
            englishText = "How much does this cost?",
            translatedText = if (targetLang == "es") "¿Cuánto cuesta esto?" else "Combien ça coûte ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "KWAHN-toh KWEHS-tah EHS-toh" else "kohm-byan sah koot"
        ))
        phrases.add(SavedPhraseEntity(
            category = "Shopping",
            englishText = "Can I pay by credit card?",
            translatedText = if (targetLang == "es") "¿Puedo pagar con tarjeta de crédito?" else "Puis-je payer par carte de crédit ?",
            targetLangCode = targetLang,
            phonetic = if (targetLang == "es") "PWEH-doh pah-GAHR kohn tahr-HEH-tah" else "pwee-zh pay-yay"
        ))

        return phrases
    }
}
