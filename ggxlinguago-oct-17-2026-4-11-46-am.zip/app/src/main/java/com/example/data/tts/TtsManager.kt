package com.example.data.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(context: Context) {
    private var textToSpeech: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentlySpeakingText = MutableStateFlow<String?>(null)
    val currentlySpeakingText: StateFlow<String?> = _currentlySpeakingText.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _pitch = MutableStateFlow(1.0f)
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    init {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                textToSpeech?.setSpeechRate(_speechRate.value)
                textToSpeech?.setPitch(_pitch.value)
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _currentlySpeakingText.value = null
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _currentlySpeakingText.value = null
                    }
                })
            }
        }
    }

    fun speak(text: String, langCode: String, isSlow: Boolean = false) {
        if (!isInitialized || text.isBlank()) return

        val locale = getLocaleForCode(langCode)
        try {
            val result = textToSpeech?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to primary language ISO code without country
                textToSpeech?.setLanguage(Locale(locale.language))
            }
        } catch (e: Exception) {
            // Graceful fallback
            textToSpeech?.language = Locale.ENGLISH
        }

        val rate = if (isSlow) 0.65f else _speechRate.value
        textToSpeech?.setSpeechRate(rate)
        textToSpeech?.setPitch(_pitch.value)

        _currentlySpeakingText.value = text
        val utteranceId = "tts_${System.currentTimeMillis()}"
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun toggleSpeak(text: String, langCode: String, isSlow: Boolean = false) {
        if (_isSpeaking.value && _currentlySpeakingText.value == text) {
            stop()
        } else {
            speak(text, langCode, isSlow)
        }
    }

    fun stop() {
        textToSpeech?.stop()
        _isSpeaking.value = false
        _currentlySpeakingText.value = null
    }

    fun setSpeechRate(rate: Float) {
        _speechRate.value = rate
        textToSpeech?.setSpeechRate(rate)
    }

    fun setPitch(pitchValue: Float) {
        _pitch.value = pitchValue
        textToSpeech?.setPitch(pitchValue)
    }

    private fun getLocaleForCode(code: String): Locale {
        val cleanCode = code.trim().lowercase()
        if (cleanCode == "auto" || cleanCode.isBlank()) {
            return Locale.getDefault()
        }

        return when (cleanCode) {
            "en" -> Locale.US
            "es" -> Locale("es", "ES")
            "fr" -> Locale.FRANCE
            "de" -> Locale.GERMANY
            "it" -> Locale.ITALY
            "pt" -> Locale("pt", "BR")
            "ru" -> Locale("ru", "RU")
            "zh", "zh-cn" -> Locale.SIMPLIFIED_CHINESE
            "zh-tw" -> Locale.TRADITIONAL_CHINESE
            "ja" -> Locale.JAPAN
            "ko" -> Locale.KOREA
            "hi" -> Locale("hi", "IN")
            "ar" -> Locale("ar")
            "bn" -> Locale("bn", "BD")
            "tr" -> Locale("tr", "TR")
            "vi" -> Locale("vi", "VN")
            "th" -> Locale("th", "TH")
            "nl" -> Locale("nl", "NL")
            "pl" -> Locale("pl", "PL")
            "id" -> Locale("id", "ID")
            "uk" -> Locale("uk", "UA")
            "el" -> Locale("el", "GR")
            "he", "iw" -> Locale("he", "IL")
            "sv" -> Locale("sv", "SE")
            "da" -> Locale("da", "DK")
            "fi" -> Locale("fi", "FI")
            "no" -> Locale("no", "NO")
            "ms" -> Locale("ms", "MY")
            "fa" -> Locale("fa", "IR")
            "ur" -> Locale("ur", "PK")
            "ta" -> Locale("ta", "IN")
            "te" -> Locale("te", "IN")
            "mr" -> Locale("mr", "IN")
            "gu" -> Locale("gu", "IN")
            "kn" -> Locale("kn", "IN")
            "ml" -> Locale("ml", "IN")
            "pa" -> Locale("pa", "IN")
            "fil", "tl" -> Locale("fil", "PH")
            "cs" -> Locale("cs", "CZ")
            "ro" -> Locale("ro", "RO")
            "hu" -> Locale("hu", "HU")
            "sk" -> Locale("sk", "SK")
            "bg" -> Locale("bg", "BG")
            "hr" -> Locale("hr", "HR")
            "sr" -> Locale("sr", "RS")
            "sl" -> Locale("sl", "SI")
            "lt" -> Locale("lt", "LT")
            "lv" -> Locale("lv", "LV")
            "et" -> Locale("et", "EE")
            "sw" -> Locale("sw", "TZ")
            "af" -> Locale("af", "ZA")
            "is" -> Locale("is", "IS")
            "ga" -> Locale("ga", "IE")
            "cy" -> Locale("cy", "GB")
            "sq" -> Locale("sq", "AL")
            "hy" -> Locale("hy", "AM")
            "ka" -> Locale("ka", "GE")
            "az" -> Locale("az", "AZ")
            "kk" -> Locale("kk", "KZ")
            "uz" -> Locale("uz", "UZ")
            "ne" -> Locale("ne", "NP")
            "si" -> Locale("si", "LK")
            "my" -> Locale("my", "MM")
            "km" -> Locale("km", "KH")
            "lo" -> Locale("lo", "LA")
            "am" -> Locale("am", "ET")
            "yo" -> Locale("yo", "NG")
            "ig" -> Locale("ig", "NG")
            "ha" -> Locale("ha", "NG")
            "zu" -> Locale("zu", "ZA")
            "xh" -> Locale("xh", "ZA")
            "eo" -> Locale("eo")
            "la" -> Locale("la")
            else -> {
                try {
                    Locale.forLanguageTag(code)
                } catch (e: Exception) {
                    Locale(code)
                }
            }
        }
    }

    fun shutdown() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        isInitialized = false
    }
}
