package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.lifecycleScope
import com.example.data.local.OmniDatabase
import com.example.data.model.ThemeMode
import com.example.data.repository.TranslationRepository
import com.example.data.tts.TtsManager
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.CameraTranslateScreen
import com.example.ui.screens.ConversationScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.OfflinePacksScreen
import com.example.ui.screens.PhrasebookScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TextTranslateScreen
import com.example.ui.theme.OmniTranslateTheme
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.TranslationViewModel

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsManager
    private lateinit var speechManager: com.example.data.speech.SpeechRecognizerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = OmniDatabase.getInstance(applicationContext)
        val repository = TranslationRepository(database.omniDao(), lifecycleScope)
        ttsManager = TtsManager(applicationContext)
        speechManager = com.example.data.speech.SpeechRecognizerManager(applicationContext)
        val viewModel = TranslationViewModel(repository, ttsManager, speechManager)

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            OmniTranslateTheme(darkTheme = isDark) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::ttsManager.isInitialized) {
            ttsManager.shutdown()
        }
        if (::speechManager.isInitialized) {
            speechManager.destroy()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: TranslationViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()

    // Handle back button to return to Translate screen
    if (selectedTab != AppTab.TRANSLATE) {
        BackHandler {
            viewModel.selectTab(AppTab.TRANSLATE)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (selectedTab != AppTab.CAMERA) {
                TopAppBar(
                    title = {
                        Text(
                            text = "OmniTranslate",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    actions = {
                        IconButton(
                            onClick = { viewModel.selectTab(AppTab.PHRASEBOOK) },
                            modifier = Modifier.testTag("topbar_phrasebook_btn")
                        ) {
                            Icon(Icons.Default.MenuBook, contentDescription = "Offline Phrasebook")
                        }
                        IconButton(
                            onClick = { viewModel.selectTab(AppTab.ANALYTICS) },
                            modifier = Modifier.testTag("topbar_analytics_btn")
                        ) {
                            Icon(Icons.Default.Analytics, contentDescription = "Analytics Dashboard")
                        }
                        IconButton(
                            onClick = { viewModel.selectTab(AppTab.SETTINGS) },
                            modifier = Modifier.testTag("topbar_settings_btn")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == AppTab.TRANSLATE,
                    onClick = { viewModel.selectTab(AppTab.TRANSLATE) },
                    icon = { Icon(Icons.Default.Translate, contentDescription = "Translate") },
                    label = { Text("Translate") },
                    modifier = Modifier.testTag("tab_translate")
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.CAMERA,
                    onClick = { viewModel.selectTab(AppTab.CAMERA) },
                    icon = { Icon(Icons.Default.CameraAlt, contentDescription = "Camera OCR") },
                    label = { Text("Camera") },
                    modifier = Modifier.testTag("tab_camera")
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.CONVERSATION,
                    onClick = { viewModel.selectTab(AppTab.CONVERSATION) },
                    icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = "Conversation") },
                    label = { Text("Speak") },
                    modifier = Modifier.testTag("tab_conversation")
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.SAVED,
                    onClick = { viewModel.selectTab(AppTab.SAVED) },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") },
                    modifier = Modifier.testTag("tab_saved")
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.OFFLINE_PACKS,
                    onClick = { viewModel.selectTab(AppTab.OFFLINE_PACKS) },
                    icon = { Icon(Icons.Default.CloudDownload, contentDescription = "Offline Packs") },
                    label = { Text("Offline") },
                    modifier = Modifier.testTag("tab_offline_packs")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                AppTab.TRANSLATE -> TextTranslateScreen(viewModel = viewModel)
                AppTab.CAMERA -> CameraTranslateScreen(viewModel = viewModel)
                AppTab.CONVERSATION -> ConversationScreen(viewModel = viewModel)
                AppTab.SAVED -> HistoryScreen(viewModel = viewModel)
                AppTab.OFFLINE_PACKS -> OfflinePacksScreen(viewModel = viewModel)
                AppTab.PHRASEBOOK -> PhrasebookScreen(viewModel = viewModel)
                AppTab.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                AppTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
